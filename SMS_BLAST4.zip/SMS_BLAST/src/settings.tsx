export const apiConfig = {
  apiKey: "Qu+a14KExO3viOV21Ar6qbal9s6kq2zGTGqeOZ96DO0=",  // Non-encoded version
  encodedApiKey: "Qu%2Ba14KExO3viOV21Ar6qbal9s6kq2zGTGqeOZ96DO0%3D",  // URL-encoded version
  clientId: "6005b6a1-5446-483a-83d0-b841d2e44b9a",

  // New API keys
  newApiKey: "MLeHYv6hNn0sk7Vb5zYwbUuExB60yh9zSaB7nlx7acY=",  // Non-encoded version
  newEncodedApiKey: "MLeHYv6hNn0sk7Vb5zYwbUuExB60yh9zSaB7nlx7acY%3D",  // URL-encoded version
  newClientId: "45322956-69fc-4755-8e53-6adf7b1d752b"

};